package com.coffeepoweredcrew.abstractfactory2;

//Abstract factory with methods defined for each object type.
public interface ResourceFactory {

}
